package com.example.demo.services;

import java.util.ArrayList;
import java.util.Optional;

import com.example.demo.models.ClienteModel;
import com.example.demo.repositories.ClienteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClienteService {
    @Autowired
    ClienteRepository clienteRepository;
    
    public ArrayList<ClienteModel> obtenerClientes(){
        return (ArrayList<UsuarioModel>) clienteRepository.findAll();
    }

    public ClienteModel guardarUsuario(ClienteModel cliente){
        return clienteRepository.save(cliente);
    }

    public Optional<ClienteModel> obtenerPorId(Long cliente_id){
        return clienteRepository.findById(cliente_id);
    }


    public ArrayList<UsuarioModel>  obtenerPorPrioridad(Integer prioridad) {
        return clienteRepository.findByPrioridad(prioridad);
    }

    public boolean eliminarCliente(Long cliente_id) {
        try{
            clienteRepository.deleteById(cliente_id);
            return true;
        }catch(Exception err){
            return false;
        }
    }
}