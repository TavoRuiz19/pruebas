package com.example.demo.controllers;

import java.util.ArrayList;
import java.util.Optional;

import com.example.demo.models.ClienteModel;
import com.example.demo.services.ClienteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/cliente")
public class ClienteController {
    static List<ClienteModel> listaClientes = new ArrayList<ClienteModel>();
    static {
        listaClientes.add(new ClienteModel(1,"pedro747", "gghrth65", "pedro", "perez", "pedro148@gmail.com",20, 1.60, 62, 19,20,16,"28-08-2021"));
    }
    @GetMapping
    public List<ClienteModel> lista() {
        return listaClientes;
    }
     @PutMapping("/{edad}/{estaura}/{peso}/{geb}")
    public void actualizar(@PathVariable("edad") int edad,@PathVariable("estaura") double estaura,@PathVariable ("peso") double peso,@PathVariable("geb") double geb,  @RequestBody ClienteModel ClienteModel) {
        listaClientes.remove(new ClienteModel(edad,estaura,peso,geb));
        listaClientes.add(ClienteModel);
    }
    @Autowired
    ClienteService clienteService;

    @GetMapping()
    public ArrayList<ClienteModel> obtenerClientes(){
        return clienteService.obtenerClientes();
    }

    @PostMapping()
    public ClienteModel guardarCliente(@RequestBody ClienteModel cliente){
        return this.clienteService.guardarCliente(cliente);
    }

    @GetMapping( path = "/{cliente_id}")
    public Optional<ClienteModel> obtenerClientePorId(@PathVariable("cliente_id") Long cliente_id) {
        return this.clienteService.obtenerPorId(cliente_id);
    }

    @RequestMapping(value = "/add/{nombre}/{apellidos}/{nombre_usuario}/{correo_electronico}/{contrasenia}",
            method = RequestMethod.POST)
    public ClienteModel addCliente(@PathVariable String nombre, @PathVariable String apellidos, @PathVariable String nombre_usuario,
            @PathVariable String correo_electronico, @PathVariable String contrasenia) {
    ClienteModel cliente = new ClienteModel();
    ClienteModel.setNombre(nombre);
    ClienteModel.setApellidos(apellidos);
    ClienteModel.setNombre_usuario(nombre_usuario);
    ClienteModel.setCorreo_electronico(correo_electronico);
    ClienteModel.setContrasenia(contrasenia);
    ClienteService.save(ClienteModel)
    return cliente;
    }

    @GetMapping("/query")
    public ArrayList<ClienteModel> obtenerUsuarioPorPrioridad(@RequestParam("prioridad") Integer prioridad){
        return this.clienteService.obtenerPorPrioridad(prioridad);
    }

    @DeleteMapping( path = "/{cliente_id}")
    public String eliminarPorId(@PathVariable("id") Long cliente_id){
        boolean ok = this.clienteService.eliminarCliente(cliente_id);
        if (ok){
            return "Se eliminó el cliente con id " + id;
        }else{
            return "No pudo eliminar el cliente con id" + id;
        }
    }

}