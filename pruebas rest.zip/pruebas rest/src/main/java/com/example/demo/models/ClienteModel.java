package com.example.demo.models;
import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "cliente")
public class ClienteModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private Long cliente_id;
    private Integer prioridad;
    private String nombre_usuario;
    private Srring contrasenia;
    private String nombre;
    private String apellidos;
    private String correo_electronico;
    private int edad;
    private double estatura;
    private double peso;
    private double imc;
    private double geb;
    private double eta;
    private fecha_creacion= new Date();
    private fecha_actualizacion = new Date();
    

    public Long getCliente_id() {
        return 
    }
    public void setCliente_id(Long cliente_id) {
        this.cliente_id = cliente_id;
    }

    public void setPrioridad(Integer prioridad){
        this.prioridad = prioridad;
    }

    public Integer getPrioridad(){
        return prioridad;
    }
    //
    public String getNombre_usuario() {
        return nombre_usuario;
    }
    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }
    //
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
    public String getContrasenia() {
        return contrasenia;
    }
    //
    public String getApellidos() {
        return apellidos;
    }
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    //
    public String getCorreo_electronico() {
        return correo_electronico;
    }

    public void setCorreo_electronico(String correo_electronico) {
        this.correo_electronico = correo_electronico;
    }
    //  
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    //
    public double getEstatura() {
        return estatura;
    }
    public void setEstatura(double estatura) {
        this.estatura = estatura;
    }
    //
     public double getPeso() {
        return peso;
    }
    public void setPeso(double peso) {
        this.peso = peso;
    }
    //
    public double getImc() {
        return imc;
    }
    public void setImc(double imc) {
        this.imc = imc;
    }
    //
    public double getGeb() {
        return geb;
    }
    public void setGeb(double geb) {
        this.geb = geb;
    }
    //
    public double getEta() {
        return peso;
    }
    public void setEta(double eta) {
        this.eta = eta;
    }
    //
    public Date getFecha_creacion() {
        return fecha_creacion;
    }
    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public Date getFecha_actualizacion() {
        return fecha_actualizacion
    }
    public void setFecha_actualizacion(Date fecha_actualizacion) {
        this.fecha_actualizacion = fecha_actualizacion;
    }

}